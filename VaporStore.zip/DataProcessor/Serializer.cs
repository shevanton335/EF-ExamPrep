﻿namespace VaporStore.DataProcessor
{
	using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Microsoft.EntityFrameworkCore;
    using Newtonsoft.Json;
    using VaporStore.Data.Models.Enums;
    using VaporStore.DataProcessor.Dto.Export;
    using VaporStore.DataProcessor.Dto.Import;

    public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			//Колекцията ни от жанрове
			List<GamesExportDto> games = new List<GamesExportDto>();
			var gamesToProcess = context
				.Games.
				AsQueryable()
				.Where(g => genreNames.Contains(g.Genre.Name))
				.Where(g=>g.Purchases.Any())
				.Include(g => g.GameTags)
				.ThenInclude(gt=>gt.Tag)
				.Include(p => p.Purchases)
				.Include(g => g.Genre)
				.ToList();

			foreach (string genre in genreNames)
			{
				var genreGames = gamesToProcess
					.Where(g => g.Genre.Name == genre)
				 	.ToList();

				if (genreGames.Count == 0)
				{
					continue;
				}

				//Превръщам ги в GamesExportDto
				var result = new GamesExportDto()
				{
					//Тук трябва да взема Id-то и името от ЖАНРА 
					Id = genreGames.First().Genre.Id,
					Genre = genreGames.First().Genre.Name,
					Games = genreGames
					.Select(g => new GameExDto()
					{
						Id = g.Id,
						Developer = g.Developer.Name,
						Title = g.Name,
						//Тук селекта връща IEnumerable
						Tags = String.Join(", ", g.GameTags.Select(t => t.Tag.Name)),
						Players = g.Purchases.Count
					})
					.OrderByDescending(g=>g.Players)
					.ThenBy(g=>g.Id)
					.ToArray()
				};
				result.TotalPlayers = result.Games.Sum(g => g.Players);

				games.Add(result);

            }
				games = games.OrderByDescending(g => g.TotalPlayers)
					.ThenBy(g => g.Id)
					.ToList();
			
			return JsonConvert.SerializeObject(games,Formatting.Indented);
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			List<UserExportDto> users = new List<UserExportDto>();
			PurchaseType purchaseType = (PurchaseType)Enum.Parse(typeof(PurchaseType), storeType);
			//Имаме UsersPurchaseType, съответно трябва да  взема Purchase-ите или User-ите
			var usersToProcess = context.Purchases
				.AsQueryable()
				.Where(p => p.Type == purchaseType)
				.Include(p => p.Game.Genre)
				.Include(p => p.Card.User)
				.ToList()
			//Тук вече ги имам групирани по User
				.GroupBy(p=>p.Card.User.Username)
				//Слагаме ToList(), който ще материализираме колекцията
				//и оттук нататък ще си работим в паметта
			.ToList();
            //Имаме всички Purchase-и, обаче на нас ни трябват да са групирани по User-и
            //Ние трябва да тръгнеме от User-а и да имаме всичките негови Purchas-ове

			//Тук имаме някаква група
            foreach (var user in usersToProcess)
            {
				var result = new UserExportDto()
				{
					username = user.Key,
					Purchases = user
					.OrderBy(p=>p.Date)
					.Select(p => new UserPurchase()
					{
						Card = p.Card.Number,
						Cvc = p.Card.Cvc,
						Date = p.Date.ToString("yyyy-MM-dd HH:mm"),
						Game = new UserPurchaseGame()
						{
							Genre = p.Game.Genre.Name,
							Price = p.Game.Price,
							title = p.Game.Name
						}
						//Не можем да видим TotalSpend защото
						//трябва да сумираме първо всичките цени
					})

					.ToArray()
				};
				//Тук слагаме селект които връща IEnumerable<decimal> 
				// и после викаме и Sum, за да се сумират
				result.TotalSpent = result.Purchases
					.Select(p => p.Game.Price)
					.Sum();
				users.Add(result);
            }
			users = users
				.OrderByDescending(ts => ts.TotalSpent)
				.ThenBy(u => u.username)
				.ToList();

			XmlRootAttribute xmlRoot = new XmlRootAttribute("Users");//Името на елемента
			XmlSerializerNamespaces xmls = new XmlSerializerNamespaces();
			xmls.Add(string.Empty, string.Empty);

			XmlSerializer serializer = new XmlSerializer(typeof(UserExportDto[]), xmlRoot);
			var sb = new StringBuilder();

			using (StringWriter sw = new StringWriter(sb))
            {
				//Малко по-нагоре направихме user-ите на TOLIST, затова си ги правим 
				//при сериализацията отново на Array
				serializer.Serialize(sw, users.ToArray(),xmls);
            }

			//.Select(p=>new UserExportDto()
			//            {
			//	username = p.Card.User.Username,

			//            })
			//.ToList();


			return sb.ToString().TrimEnd();
		}
	}
}